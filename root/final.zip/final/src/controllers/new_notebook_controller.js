(function(global) {

  global.myapp.controller('NewNotebookDialog', ['$scope', 'Notebooks', function($scope, Notebooks) {


  }]);

}(this));