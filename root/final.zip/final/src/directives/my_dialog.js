(function(global) {

  global.myapp.directive('myModel', [function() {
    return {
      restrict: 'A',
      scope: {
        'data' : '=myModel'
      },
      link: function($scope, $element, $attr) {
        $element.on('input', function() {
          console.dir(arguments);
          console.dir($element);
          console.log($element.val());
          $scope.data = $element.val();
          $scope.$apply();
        });
      }

    }
  }]);

  global.myapp.directive('myClicks', [function() {
    return {
      template: '<p>{{counter}}</p>',

      restrict: "E",

      scope: {
        counter:'@count'
      },

      compile: function (tElement, tAttrs) {
        tAttrs.count = tAttrs.count || 7;
        console.log('COMPILE');

        return function ($scope, $element, $attr, $controller) {
          console.log('LINK');
          $element.on('click', function() {
            console.log('CLICK!. counter = ' + $scope.counter);
            console.dir($scope);
            $scope.counter++;
            $element.find('p').html($scope.counter);

          });
          // Binding code goes here
        }
      }
    }
  }]);


  global.myapp.directive('myDialog', ['$rootScope', function($rootScope) {
    return {
      scope: {
        dlgOk: '&',
        dlgId: '@',
        dlgTitle: '@'
      },
      restrict: "E",

      templateUrl: 'src/directives/my_dialog.html',
      transclude: true
    };
  }]);

  global.myapp.directive('dlgText', ['$rootScope', function($rootScope) {
    return {
      scope: {
        'ngModel' : '='
      },
      restrict: "E",
      template:
        '<div class="form-group">' +
          '<label for="note-title">Title</label>' +
          '<input type="text" ng-model="ngModel" class="form-control" id="note-title" placeholder="Enter name...">' +
        '</div>'
    };
  }]);

  global.myapp.directive('dlgTextarea', ['$rootScope', function($rootScope) {
    return {
      scope: {
        'ngModel' : '='
      },
      restrict: "E",
      template:
        '<div class="form-group">' +
          '<label for="note-title">Text</label>' +
          '<textarea class="form-control" ng-model="ngModel" placeholder="Type some text..."></textarea> ' +
          '</div>'
    };
  }]);


}(this));
