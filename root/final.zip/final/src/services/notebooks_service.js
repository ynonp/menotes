(function(global) {

  global.myapp.factory('Notebooks', ['$http', '$rootScope', function($http, $rootScope) {
    var _notebooks = [];

    return {
      add_notebook: function(name) {
        $rootScope.$broadcast('notebook.start_add');
        $http.post('/notebooks', { name: name })
          .success(function(res, status) {
            _notebooks.push(res.data);
            $rootScope.$broadcast('notebook.end_add');
          })
          .error(function(res, status) {
            $rootScope.$broadcast('notebook.end_add');
          });
      },

      add_note: function(notebook_id, note_title, note_text) {
        $rootScope.$broadcast('note.start_add');
        $http.post('/notebooks/' + notebook_id + '/notes', { title: note_title, text: note_text })
          .success(function(res, status) {
            console.log('note add ok');
            $rootScope.$broadcast('note.end_add', notebook_id);
          })
          .error(function(res, status) {
            $rootScope.$broadcast('note.end_add');
          });
      },

      fetch: function() {
        $http.get('/notebooks')
          .success(function(res, status) {
            Array.prototype.splice.apply(_notebooks,[0,_notebooks.length].concat(res.data));
          })
          .error(function(res, status) {
            console.log('Error: ' + res);
            console.dir(res);
            console.dir(status);
            $rootScope.$broadcast('error', res, status);
          });

        return _notebooks;
      },

      fetch_notes: function(notebook_id) {
        var notes = [];

        $http.get('/notebooks/' + notebook_id + '/notes')
          .success(function(res, status) {
            Array.prototype.splice.apply(notes,[0,notes.length].concat(res.data.notes));
          })
          .error(function(res, status) {
            $rootScope.$broadcast('error', res, status);
          });

        return notes;
      }
    }
  } ]);

}(this));