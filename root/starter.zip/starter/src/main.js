(function(global) {

  global.myapp = angular.module('MyApp', []);

}(this));