(function(global) {

  global.myapp.controller('NewNoteDialog', ['$scope', 'Notebooks', function($scope, Notebooks) {
  }]);
}(this));